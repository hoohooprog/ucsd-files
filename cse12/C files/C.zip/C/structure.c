#include <stdio.h> 
#include <string.h> 
struct contact
{
       char lastname[25];
       char firstname[25];
       int areaCode;
       int phoneNumber;
};
int main(int argc, char *argv[]) {
	int i;
	struct contact phonebook[100]; 
	strcpy(phonebook[1].lastname,"Papadopoulos"); 
	strcpy(phonebook[0].lastname,"Alvarado");
	strcpy(phonebook[2].lastname,"Langlois"); 
	phonebook[0].areaCode=phonebook[1].areaCode = 858;
	phonebook[2].areaCode=773;

	printf("sizeof(struct contact): %lu \n", sizeof(struct contact)); 
	printf("sizeof(phonebook): %lu \n", sizeof(phonebook));
	for (i = 0; i <= 2; i++)
		printf("phonebook[%d](lastname,areaCode) (%s,%d)\n",i, 
			phonebook[i].lastname, phonebook[i].areaCode);
}

