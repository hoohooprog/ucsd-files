#include <stdio.h>
#include <string.h>
#include "structure.h"


CONTACT formFill(char last[], int code) {
	CONTACT rval; 
	strcpy(rval.lastname, last); 
	rval.areaCode = code;
	return rval;
}

void modifyForm(CONTACT form, char last[], int code)
{
    strcpy(form.lastname, last);
    form.areaCode = code;
}

void printbook(CONTACT book[], int nentries) {
       int i;
       for (i = 0; i < nentries; i++)
		  printf("book[%d](lastname,areaCode) (%s,%d)\n",i, 
		  	book[i].lastname, book[i].areaCode);
}


int main(int argc, char *argv[])
{
	int i;
	CONTACT phonebook[100];
	phonebook[0] = formFill("Papadopoulos", 858); 
	phonebook[1] = formFill("Alvarado", 858);
 	phonebook[2] = phonebook[1]; /* copy entries */


	printf("sizeof(CONTACT): %d \n", (int)sizeof(CONTACT)); 
	printf("sizeof(phonebook): %d \n", (int)sizeof(phonebook)); 
	printbook(phonebook,3);
	/* Modify entry 2 last name */
	printf("Modify entry 2\n");
	modifyForm(phonebook[2], "Smith", 619);
	printbook(phonebook, 3);
}