#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "LinkedList.h"

#define MAXLINE 1024

/** Create a node in the list
* @param val pointer to data referenced by this node 
* val - the */

NODE * createNode(void * val)
{
	NODE * rNode;
	rNode = (NODE *) malloc(sizeof(NODE));
 	rNode->elem = val;
	rNode->link = (NODE *) NULL;
	return rNode;
}

/** destroy a Node
* @param node - the NODE to destroy
* @param freeElem - if nonzero, free the element referenced
*/

void destroyNode(NODE * node, int freeElem)
{
   if (! node ) return;
   if (freeElem && node -> elem)
   free( node -> elem );
   free(node);
}

/** destroy a list 
 * @param list reference for this list
 * @param freeElem if nonzero, also free memory associated with user data
*/
void destroyList(SLLIST *list, int freeElem)
{
	if (!list) return;
	NODE * node, *tmp;
	node = list -> head;
	while (node)  // destroy the linked list of nodes
	{
		tmp = node;
		node = node -> link;
		destroyNode(tmp, freeElem);
	}
	free(list);
}

/** Insert an element to the front SLLIST
 * @param list the list to manipulate
 * @param elem  data to record
 * @return OK if successful, FAIL otherwise
 */
int insertElem(SLLIST * list, void * elem) // Add element at head of list
{
	return insertElemIndex(list, elem, 0);
}
/** Create a Singly Linked List
* This uses a sentinel for the head node */

SLLIST * createList()
{
    SLLIST *rval;
	rval = (SLLIST *) malloc(sizeof(SLLIST));
	rval -> size = 0;
	rval -> head = createNode( (void *) NULL);
	return rval;
}


int insertElemIndex(SLLIST * list, void * elem, int idx)
{
    int i;
	if (!list || !elem) return FAIL;
	NODE * new;
	NODE * head = list->head;
	for (i = 0; i < idx; i ++) {
		head = head->link;
		if (!head) return FAIL;
	}

	new = createNode(elem);
	new->link = head->link;
	head->link = new;
	list -> size ++;
	return OK;
}


void * removeElemIndex(SLLIST * list, int idx)
{
   int i;
	if (! list) return (void *) NULL;
	NODE * r; NODE * head = list->head;
	void * rval;
	for (i = 0; i < idx; i ++) {
		head = head->link;
		if (!head) return (void *) NULL;
	}

	if (r = head -> link){
		rval = r->elem;
		head->link = r->link;
		destroyNode(r, FALSE); 
		list -> size --;
		return rval;
	}
return (void *) NULL;
}


void usage()
{
	fprintf(stderr, "reverse <filename> \n");
}
int main (int argc, char **argv)
{
	char * fname;   //file name
	FILE * rfile;   
	char * str;
	char linebuf[MAXLINE];
	SLLIST * list;  //new list

	if (argc != 2 )
	{
		usage();
		exit(-1); //exit with error code -1. 
	}
	fname = argv[1];

	if (! (rfile = fopen(fname,"r")))
	{
		fprintf(stderr,"Could not open file: %s \n", fname);
		exit(-1);
	}
	
	list = createList();

/* fgets reads a line from the specified stream 
*  and stores it into the string pointed to by str. 
*  It stops when either (n-1) characters are read, 
*  the newline character is read, or the end-of-file 
*  is reached, whichever comes first.
*/

	while (fgets(linebuf,MAXLINE-1,rfile) != NULL)
	{
		linebuf[MAXLINE-1] = '\0'; // force string termination
		str = malloc(strlen(linebuf)+1);
		strcpy(str,linebuf);
		insertElem(list,str);
	}


	NODE * n;
	n = list -> head;
	while ( (n = n -> link))
		printf("%s",n->elem);
	destroyList(list,TRUE);
}



	






