#include <stdio.h>
#include <string.h>


int main(int argc, char *argv[])
{
   
   int intArray[100];
   int *intPointer =&(intArray[0]);
   int k=3;

  printf("intArray: %d, *intPointer: %d\n", intArray, *intPointer);
  printf("intArray[0]: %d, *intPointer: %d\n", intArray[0], *intPointer);
  printf("intArray[k]: %d, *(intPointer+k): %d\n", intArray[k], *(intPointer+k));
  printf("intArray: %d, &intArray: %d, intPointer: %d\n", intArray, &intArray, intPointer);  

   
} 

