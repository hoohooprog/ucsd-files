#include <stdio.h>
#define T_F(e) ((e) == 0 ? "False" : "True")

int main(int argc, char *argv[])
{
   int a = 1, b = 2;
   printf("a = %d -- b = %d\n", a, b );
   printf("a & b = %d -- a && b = %d\n", a & b, a && b);
   printf("a & b = %s -- a && b = %s\n", T_F(a & b), T_F(a && b));
   
}