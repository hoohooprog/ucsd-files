#include <stdio.h>

int main(int argc, char *argv[])
{
   float x = 34.5;
   int i = 4;
   printf("x = %f, i = %f, i * x = %f\n", x, i, i * x);
}
