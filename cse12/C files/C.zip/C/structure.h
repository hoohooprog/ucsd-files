typedef struct 
{
       char lastname[25];
       char firstname[25];
       int areaCode;
       int phoneNumber;
} CONTACT;