#include <stdio.h>

void func2(int num)
{
    num = 7;
} 

void func1(int *x) 
{
    *(x+1) = 7; 
}

int main()
{
	int arr[4]={2, 4, 6} ;
	int number = 10;
	int *ptr=arr;
	


   /*   	printf("%d \n", *(ptr+1));  

  	printf("%d \n", *(ptr+1));  
  	
  	func1(ptr);
  	printf("%d \n", arr[1]);  
  	
  	func2(number);
	printf("%d \n", number);  */
	
	int a[3];
    int *p = a;
    
    printf("%d \n", p);  

    

}






