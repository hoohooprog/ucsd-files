#include <stdio.h>
#include <string.h>


int main(int argc, char *argv[])
{
   
  
   int a = 5;
   float c =10.5;

   int *i_ptr = &a;
   void *v_ptr = &a;

   printf("i_ptr = %d, v_ptr = %d \n", *i_ptr, *v_ptr);  

   

  
  
} 

