#include <stdio.h>
#include <string.h>
#include "structure.h"




CONTACT formFill(char last[], int code) {
	CONTACT rval; 
	strcpy(rval.lastname, last); 
	rval.areaCode = code;
	return rval;
}
void printbook(CONTACT book[], int nentries) {
       int i;
       for (i = 0; i < nentries; i++)
		  printf("book[%d](lastname,areaCode) (%s,%d)\n",i, 
		  	book[i].lastname, book[i].areaCode);
}


int main(int argc, char *argv[])
{
	int i;
	CONTACT phonebook[100];
	phonebook[0] = formFill("Papadopoulos", 858); 
	phonebook[1] = formFill("Alvarado", 858);
 	phonebook[2] = phonebook[1]; /* copy entries */
    phonebook[3] = formFill("Langlois", 737); 
    
	printf("sizeof(CONTACT): %d \n", (int)sizeof(CONTACT)); 
	printf("sizeof(phonebook): %d \n", (int)sizeof(phonebook)); 
	printbook(phonebook,4);
	/* Modify entry 2 last name */
	printf("Modify entry 2\n");
	phonebook[2] = formFill("Smith", 619);
	printbook(phonebook, 4);
}

