/* linkedList.h - header file for simple linked list of strings */

#define OK 0
#define FAIL -1
#define TRUE 1
#define FALSE 0

/* Define Linked List Structure of Node, and List */

struct Node
{
   void *elem; //!< data element
   struct Node *link; //!< link to next node
};

typedef struct Node NODE;
struct SLList
{
   int size; //!< size of the list
   struct Node *head; //!< head of list
};

typedef struct SLList SLLIST;
NODE * createNode(void * val);
void destroyNode(NODE * node, int freeElem);
SLLIST * createList();
void destroyList(SLLIST *list, int freeElem);
int insertElem(SLLIST * list, void * elem); 
int insertElemIndex(SLLIST * list, void * elem, int idx);
void * removeElem(SLLIST * list);
void * removeElemIndex(SLLIST * list, int idx);