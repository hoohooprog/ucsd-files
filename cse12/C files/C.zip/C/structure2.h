typedef struct 
{
       char lastname[25];
       char firstname[25];
       int areaCode;
       void (*print)(struct contact *); /* pointer to func that prints */
} CONTACT;

/* prototype declarations */

void formFill(CONTACT * t, char last[], int code);

void printbook(CONTACT book[], int nentries);