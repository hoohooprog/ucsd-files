/**
 * Name: Jingyi Tay <<< --- Replace with Your Name
 * Login: cs12wamf <<< --- Use your cs11f course-specific account name
 * Date: February 26, 2017
 * File: HashTable.java
 * Sources of Help: stackoverflow, piazza, open-source murmur code,
 * tutorialpoint
 *
 * This is a implementation of a Hashtable that will be implemented
 * as a dictionary for SpellChecker.java.
 * The hashtable resizes at 2*collision+1 when load factor is at 0.67.
 *
*/

package hw8;

import java.util.LinkedList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class HashTable implements IHashTable {
	
	//You will need a HashTable of LinkedLists. 
	//Number of element stored in the hash table
	private int nelems;  
	//Number of times that the table has been expanded
	private int expand;  
	//Number of collisions since last expansion
	private int collision; 
	private int lenOfCollisionChain;
	//FilePath for the file to write statistics upon every rehash
	private String statsFileName; 
	//Boolean to decide whether to write statistics to file or not after rehashing
	private boolean printStats = false;  
	// instantiate hash fn object
	private MurmurHash hashfn = new MurmurHash();
	private LinkedList[] hashTable;
	
	
	private float loadFactor;
	
	
	/**
	 * Constructor for hash table
	 * @param Initial size of the hash table
	 */
	public HashTable(int size) {
		
		//Initialize
		nelems = 0;
		
		hashTable = new LinkedList[size];
							
		//System.out.println("hash table size: " + hashTable.length);
	}
	
	
	/**
	 * Constructor for hash table
	 * @param Initial size of the hash table
	 * @param File path to write statistics
	 */
	public HashTable(int size, String fileName){
		
		nelems = 0;
		
		hashTable = new LinkedList[size];
		
		//Set printStats to true and statsFileName to fileName
		printStats = true;
		statsFileName = fileName;
		
	}

	
	/** Insert the string value into the hash table
	 * 
	 * @param value value to insert
	 * @throws NullPointerException if value is null
	 * @return true if the value was inserted, false if the value was already present
	 */
	@Override
	public boolean insert(String value) {
		
		int totalIndexes = 0;
		
		long hash;
		
		boolean inserted = false;
		
		if (value == null){
			throw new NullPointerException();
		}
		
		hash = hashfn.hash64(value,hashTable.length);
		
	    // if upon 1st hash, element is empty, insert key
		if (hashTable[((int)hash)] == null){
		
			hashTable[(int)hash] = new LinkedList<String>();
			
			hashTable[(int)hash].add(value);
			
			nelems++;
			
			totalIndexes = hashTable.length;
			
			while (totalIndexes % 2 == 0 || totalIndexes % 3 == 0){
				totalIndexes =totalIndexes*expand+1;
			}
				
			// calculate new load factor
			loadFactor = nelems/totalIndexes;
				
			// check if loadFactor >= 0.666, if so, resize and rehash
			if (loadFactor >= 0.666){
				expand++;
					
				rehash(hashTable);
					
				if (printStats){
					printStatistics(statsFileName);
				}
					
				//reset statistics
				loadFactor = 0;
				lenOfCollisionChain = 0;
				collision = 0;
					
			}
			inserted = true;
					
			return inserted;
		}
		
		// if exact value found, return false
		if (hashTable[(int)hash].contains(value)){
			
			inserted = false;
			
			return inserted;				
		}
		
		/**
		 * if hashTable doesn not contain value and linkedlist is
		 * not new, check loadfactor, resize and add value
		 */
		if (hashTable[(int)hash] != null){
			hashTable[(int)hash].add(value);
			
			nelems++;
			

			totalIndexes = hashTable.length;
			
			while (totalIndexes % 2 == 0 || totalIndexes % 3 == 0){
				totalIndexes =totalIndexes*expand+1;
			}
				
			// calculate new load factor
			loadFactor = nelems/totalIndexes;
				
			// check if loadFactor >= 0.666, if so, resize and rehash
			if (loadFactor >= 0.666){
				expand++;
					
				rehash(hashTable);
					
				if (printStats){
					printStatistics(statsFileName);
				}
					
				//reset statistics
				loadFactor = 0;
				lenOfCollisionChain = 0;
				collision = 0;
					
			}
			
			return inserted;
		}
		
		// if chanced upon null after deletion or occupied index, keep 
		// generating hash until same object is found or null before deletion
		while (!inserted){
			
			for (int i=0; i<hashTable[(int)hash].size(); i++){
			    if (hashTable[(int)hash].get(i) == "bridge"){
				
				    hashTable[(int)hash].add(i,value);
				
				    //System.out.println(value);
				    nelems++;
			    }
			    
			    totalIndexes = hashTable.length;
				
				while (totalIndexes % 2 == 0 || totalIndexes % 3 == 0){
					totalIndexes =totalIndexes*expand+1;
				}
					
				// calculate new load factor
				loadFactor = nelems/totalIndexes;
				
				
				// check if loadFactor >= 0.666, if so, resize and rehash
				if (loadFactor >= 0.666){
					expand++;
					
					rehash(hashTable);
					
					if (printStats){
						printStatistics(statsFileName);
					}
					
					//reset statistics
					loadFactor = 0;
					lenOfCollisionChain = 0;
					collision = 0;
					
				}
			}
			inserted = true;
		}
		
		return inserted;
	}

	
	/** Delete the given value from the hash table
	 * 
	 * @param value value to delete
	 * @throws NullPointerException if value is null
	 * @return true if the value was 8+
	 * deleted, false if the value was not found
	 */
	@Override
	public boolean delete(String value) {
		
		long hash;
		boolean valExist = false;
		boolean isBridged = false;
		
		if (value == null){
			throw new NullPointerException();
		}
		
		// find the hash of key by running hashfn
		hash = hashfn.hash64(value, hashTable.length);
		
		// if 1st hash fn gen found value, delete it and return true
		if (hashTable[((int)hash)].contains(value)){
			hashTable[(int)hash].set(hashTable[((int)hash)].indexOf(value), "bridge");
			
			nelems--;
			
			return true;
		}
		else{
			return false;
		}
		
	}

	
	/** Check if the given value is present in the hash table
	 * 
	 * @param value value to look up
	 * @throws NullPointerException if value is null
	 * @return true if the value was found, false if the value was not found
	 */
	@Override
	public boolean contains(String value) {
		
		long hash;
		
		if (value == null){
			throw new NullPointerException();
		}

		hash = hashfn.hash64(value, hashTable.length);
		
		if (hashTable[(int)hash]==null){
			return false;
		}
		
		// if 1st try found value, return
		return (hashTable[((int)hash)].contains(value));
		
	}

	
	/** Print the contents of the hash table. Print nothing if table is empty
	 * 
	 */
	@Override
	public void printTable() {
		int z = 0;
		
		if (nelems==0){
			return;
		}
		else{
			for (int i=0; i<hashTable.length; i++){
				
				if (hashTable[i] != null){
				
					for (int j=0; j<hashTable[i].size(); j++){
						System.out.println(z + ": " + hashTable[i].get(j));
						z++;
					}
				}
			}
		}
	}
	
	
	/**
	 * Return the number of elements currently stored in the hashtable
	 * @return nelems
	 */
	@Override
	public int getSize() {
		
		return nelems;
	}
	
	
	/**
	 * Takes in hashTable and assign a larger hashTable to the 
	 * reference.
	 * @param hashTable
	 */
	private void rehash( LinkedList[] hashTable ){
		
		long hash;
		String tempStore;
		LinkedList[] tempTable = new LinkedList[hashTable.length*2];
		
		// increase resize count
		expand++;
		
		// create a table that is double the length and 
		// reinsert into new table
		for (int i=0; i<hashTable.length; i++){
			
			if (hashTable[i] != null){
			
				//iterate through the linkedlist of each index and 
				// reassign the key to a new hash
			    for (int j=0; j<hashTable[i].size();j++){
			
				    if (hashTable[i].get(j) == "bridge"){
				        break;
				    }
				    else{
				    	 
				    		 tempStore = (String)hashTable[i].get(j);
				    		 
				    		 
				    		 hash = hashfn.hash64(tempStore, tempTable.length);
				    			
				    		 // if list is new
				    		 if (tempTable[(int)hash]==null){
									    
				    			 tempTable[(int)hash] = new LinkedList();
									  
								    
				    		 }
				    			 
				    		 tempTable[(int)hash].add(tempStore);	    
						      	
					    }
				    }
			    }
		    }

		    //assign new table object to ref hashTable
		    hashTable = tempTable;	
	}
	
	
	/**
	 * printStatistics() to print the statistics after each expansion.
	 * This method will be called from insert/rehash only if printStats=true
	 * @param fileName
	 */
	private void printStatistics(String fileName){
		
		BufferedWriter bw = null;
		FileWriter fw = null;
		
		try{
		
			String content = new String( expand + "resizes, " +
		        "load factor " + loadFactor + ", " + collision
		        + " collisions, " + lenOfCollisionChain +
		        " longest chain");
		
			fw = new FileWriter(fileName);
			bw = new BufferedWriter(fw);
			bw.newLine();
			bw.write(content);
		} catch (IOException e){
			System.out.println("no file inserted");
		}
	}

	
	/**
	 * Purpose: To generate "random" hash value based on length of tabl
	 * and size of text.
	 * @author Jingyi Tay
	 * @version 1.0
	 * @since March 9, 2017
	 */
	protected class MurmurHash {
	    
		private int size;
				
	    // all methods static; private constructor. 
	    public MurmurHash() {}

	    
	    /** 
	     * Generates 64 bit hash from byte array of the given length and seed.
	     * 
	     * @param data byte array to hash
	     * @param length length of the array to hash
	     * @param seed initial seed value
	     * @return 64 bit hash of the given array
	     */
	    public long hash64(byte[] data, int length, int seed) {
	        long m = 0xc6a4a7935bd1e995L;
	        int r = 47;
	   
	        long h = (seed&0xffffffffl)^(length*m);

	        int length8 = length/8;

	        for (int i=0; i<length8; i++) {
	            final int i8 = i*8;
	            long k =  ((long)data[i8+0]&0xff)      +(((long)data[i8+1]&0xff)<<8)
	                    +(((long)data[i8+2]&0xff)<<16) +(((long)data[i8+3]&0xff)<<24)
	                    +(((long)data[i8+4]&0xff)<<32) +(((long)data[i8+5]&0xff)<<40)
	                    +(((long)data[i8+6]&0xff)<<48) +(((long)data[i8+7]&0xff)<<56);
	           // System.out.println("k after additive shift: " + k);
	            
	            k *= m;
	            
	            //System.out.println("k after multiply by m:" + k);
	            k ^= k >> r;
	           // System.out.println("k after logical shift by r and xor:" + k);
	            k *= m;
	           // System.out.println("k after multiply by m:" + k);
	            h ^= k;
	           // System.out.println("h after xor by k:" + h);
	            h *= m; 
	          //  System.out.println("h after multiply by m:" + h);
	        }
	        
	        switch (length%8) {
	        case 7: h ^= (long)(data[(length&~7)+6]&0xff) << 48;
	        case 6: h ^= (long)(data[(length&~7)+5]&0xff) << 40;
	        case 5: h ^= (long)(data[(length&~7)+4]&0xff) << 32;
	        case 4: h ^= (long)(data[(length&~7)+3]&0xff) << 24;
	        case 3: h ^= (long)(data[(length&~7)+2]&0xff) << 16;
	        case 2: h ^= (long)(data[(length&~7)+1]&0xff) << 8;
	        case 1: h ^= (long)(data[length&~7]&0xff);
	                h *= m;
	        };
	     
	        //System.out.println("h after switch:" + h);
	        h ^= h >> r;
	        //System.out.println("h after logical right shift by r and xor:" + h);
	        h *= m;
	       // System.out.println("h after multiply by m:" + h);
	        h ^= h >> r;
	       // System.out.println("h after logical right shift by r and xor:" + h);
	       // System.out.println("hash index by table size: " + h%this.size);

	        return h%this.size;
	    }
	    
	    /** 
	     * Generates 64 bit hash from byte array with default seed value.
	     * 
	     * @param data byte array to hash
	     * @param length length of the array to hash
	     * @return 64 bit hash of the given string
	     */
	    public long hash64(byte[] data, int length) {
	        return hash64(data, length, 0xe17a1465);
	    }

	    /** 
	     * Generates 64 bit hash from a string.
	     * 
	     * @param text string to hash
	     * @return 64 bit hash of the given string
	     */
	    public long hash64(String text, int size) {
	        byte[] bytes = text.getBytes(); 
	        this.size = size;
	       
	        //System.out.println("bytes of text: " + bytes );
	        return hash64(bytes, bytes.length);
	    }
	    
	}
}








