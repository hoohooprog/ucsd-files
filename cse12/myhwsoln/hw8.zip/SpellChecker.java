package hw8;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * Name: Jingyi Tay <<< --- Replace with Your Name
 * Login: cs12wamf <<< --- Use your cs11f course-specific account name
 * Date: March 9, 2017
 * File: SpellChecker.java
 * Sources of Help: stackoverflow, piazza,,
 * tutorialpoint,https://www.tutorialspoint.com/java/java_string_split.htm
 *
 * This is a program that accepts a list of words and store them as a 
 * dictionary using hashtable while having another list of words and
 * outputs the possible words or identify the words that are in the
 * dictionary.
 *
*/
public class SpellChecker {
	
	HashTable dictHash = new HashTable(10);
	String words[];
	boolean altsFound = false;

	public SpellChecker(String dictionary, String input){
		
		/*
		 * use scanner to scan words in dictionary and then store in HashTable
		 */
		File dictFile = new File(dictionary);
		String dictWord;
		try{
		    // Open the file
		    FileInputStream fstream = new FileInputStream(dictionary);
		    BufferedReader br = new BufferedReader
		    		(new InputStreamReader(fstream));

		    String strLine;

		    //Read File Line By Line
		    try {
				while ((strLine = br.readLine()) != null) {
				  // Print the content on the console
				  System.out.println(strLine);
				  dictHash.insert(strLine);
				  
				}
				
				//Close the input stream
				br.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		    		
		}catch(FileNotFoundException e){}

		//get input to check, but first store dict in hashTable
		File inputFile = new File(input);
		String inputWord;
		
		try{
			
			Scanner scannerInput = new Scanner(inputFile);
			while(scannerInput.hasNextLine()){
				inputWord = (scannerInput.nextLine()).toLowerCase();
				
				System.out.print(inputWord + ": ");
				
				if (dictHash.contains(inputWord)){
					System.out.println("ok");
				}
				else{
					/*
					 * check words for any possible mistakes
					 * and output to user the possible corrections
					 */
					wrongLetterCheck(inputWord);
					insertLetterCheck(inputWord);
					checkAdjacentLetters(inputWord);
					checkInsSpace(inputWord);
					deletedLetterCheck(inputWord);
					
					if (altsFound == false){
						
						System.out.print("not found");
						
					}
					System.out.println();
					altsFound = false;
				}
				
			}
		}catch(FileNotFoundException e) {
			System.out.println("\nFile not found!!");
		}
	}
	
	/**
	 * takes in word and check whether any letter in the word is 
	 * misplaced.
	 * @param word
	 */
	private void wrongLetterCheck(String word){
		
		String stringOfChar;
		String charContainer;
		
		// index to be tested against all letters
		for (int i=0; i<word.length();i++){
			
			// a starts from 96 and ends at 122(z)
			char letter = 'a';
			char[] wordArr = word.toCharArray();
			
			//range of all letters to be tested in a index
			for (int j=0; j<26;j++){
				wordArr[i] = letter;
				charContainer = new String(wordArr);
				
				if (dictHash.contains(charContainer)){
					System.out.print(charContainer + " ");
					altsFound = true;
				}
				letter++;
			}
		}
	}
	
	/**
	 * takes in a word and inserts a additional letter and check
	 * if the new word is a possible word in the dictionary.
	 * @param word
	 */
	private void insertLetterCheck(String word){
		
		String charContainer;
		
		
		// iterate and store all possible combination in array using its size
		for (int i=0; i<=word.length();i++){
			char letter = 'a';
			// inserted the range of letters at the index in char arr
			for (int j=0; j<26;j++){
				char wordArr[] = new char[word.length()+1];
				// insert letter at specific index in arr
				wordArr[i] = letter;
				int counter = 0;
				// iterate thru wordArr starting from beginning
				// only insert if null
				for (int z=0; z<word.length()+1;z++){
					
					if (wordArr[z]== 0){
						
						wordArr[z] = word.charAt(counter);
						// change to next letter
						counter++;
					}
				}
				
				// convert to string and test if dict has word
				// if so print char
				charContainer = new String(wordArr);
				
				if (dictHash.contains(charContainer)){
					System.out.print(charContainer + " ");
					altsFound = true;
				}
				//change letter to insert
				letter++;
			}
		}
	}
	
	
	/**
	 * accepts word and deletes a letter from the word from
	 * different positions and see if the new words are contained
	 * in the dictionary.
	 * @param word
	 */
	private void deletedLetterCheck(String word){
		
		int counter=0;
		//int charPointer=0;
		String charContainer;
		
		// iterate thru the whole word to delete each word
		for (int i=0; i<word.length();i++){
			
			// make a char array 1 size smaller
			char[] lessWord = new char[word.length()-1];
			
			// iterate thru word again and if i met counter don't print 
			for (int j=0; j<word.length()-1;j++){
		        
				// if current index not = to counter, copy char
				if (j!=counter){
		    	    lessWord[j] = word.charAt(i);
		    	    //charPointer++;
		        }
				
			}
			
			charContainer = new String(lessWord);
			
			if (dictHash.contains(charContainer)){
				System.out.print(charContainer + " ");
				altsFound = true;
			}
		
			counter++;
		}
		
	}
	
	
	/**
	 * receives a word and flips the positions of adjacent words
	 * in a letter to check if the words are any words in the dictionary.
	 * @param word
	 */
	private void checkAdjacentLetters(String word){
		
		String charContainer;
	
		// from 1st index to last 2nd index
		for (int i=0; i< word.length()-1; i++){
			
			//store word in local string &
			// make 2 chars to store before n after
			char[] rearrangedWord = word.toCharArray();
			char newChar = rearrangedWord[i+1];
			//System.out.println(newChar);
			char oldChar = rearrangedWord[i];
			
			rearrangedWord[i] = newChar;
			rearrangedWord[i+1] = oldChar;
			
			//System.out.println(rearrangedWord);
			
			charContainer = new String(rearrangedWord);
			
			//find out if dict contains word
			if (dictHash.contains(charContainer)){
				System.out.print(charContainer + " ");
				altsFound = true;
			}
			
		}
		
	}
	
	
	/**
	 * receives a word and insert space in between each position of 
	 * the word. The word is then split and tested for any possible
	 * words of the dictionary.
	 * @param word
	 */
	private void checkInsSpace(String word){
		
		String charContainer;
		int insertSpace = 1;
		boolean spaceInserted = false;
		char[] wordArr = new char[word.length()+1];
		
		wordArr[0] = word.charAt(0);
		wordArr[word.length()] = word.charAt(word.length()-1);
		
		// iterate thru the length of word
		for (int i=1; i<word.length()-1; i++){
			int insertLetterAfterSpace=1;
			
			// store word in char array, insert space when i is met
			for (int j=1; j<wordArr.length-1; j++){
				
				if (j==insertSpace){
					wordArr[j] = ' ';
					
				}
				else{
				    wordArr[j] = word.charAt(insertLetterAfterSpace);
				    insertLetterAfterSpace++;
				}
				
			}
			insertSpace++;
			charContainer = new String(wordArr);
			
			//System.out.println(charContainer);
			
			String[] subContainer1 = charContainer.split(" ");
			
			//System.out.println(subContainer1[0]);
			//System.out.println(subContainer1[1]);
			
			for (int z=0; z<2; z++){
		        if (dictHash.contains(subContainer1[z])){
					    System.out.print(subContainer1[z] + " ");
					    
					    altsFound = true;
				}
			}
			
			spaceInserted = false;
			
		}
	}
	
	public static void main( String[] args ) {
		
		String dictName = args[0];
		String input = args[1];
	
		SpellChecker testCheck = new SpellChecker(dictName,input);
	}
	
}
