/**
 * Name: Jingyi Tay <<< --- Replace with Your Name
 * Login: cs12wamf <<< --- Use your cs11f course-specific account name
 * Date: March 9, 2017
 * File: HashTableTester.java
 * Sources of Help: stackoverflow, piazza, tutorialpoint
 *
 * tester for the hashtable class.
 *
*/

package hw8;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class HashTableTester {

	HashTable table = new HashTable(20);
	boolean truFalse = false;
	
	
	@Test
	public void testInsert(){
		table.insert("value");
		table.printTable();
		assertTrue("table contains keyword \"value\"", table.contains("value"));
		assertTrue("table cannot insert \"value\" again", !table.insert("value"));
		
		table.insert("eulav");

		// table should have eulav and value in different index
		table.printTable();
		
		table.insert("uelva");
		
		table.insert("bobcat");
		
		table.printTable();
	}
	
	
	@Test 
	public void testDelete(){
		
		table.insert("value");
		table.delete("value");
		assertTrue("value is gone", !table.contains("value"));
	}
	
	
	@Test
	public void testGetSize(){
		table.insert("value");
		table.insert("eulav");
		table.insert("bobcat");
		
		assertEquals("size of table is 3",3 , table.getSize());
	}
}
