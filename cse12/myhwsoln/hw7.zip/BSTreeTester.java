package hw7;
/**
 * Name: Jingyi Tay <<< --- Replace with Your Name
 * Login: cs12wamf <<< --- Use your cs11f course-specific account name
 * Date: February 26, 2017
 * File: BSTreeTester.java
 * Sources of Help: stackoverflow, piazza
 *
 * This program uses test cases to test each methods of the 
 * implementation of the BST methods in 
 * BSTree.java
 *
*/

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;
import java.util.Iterator;

public class BSTreeTester {
	
	BSTree<String> myTree = new BSTree<String>();
	Iterator<String> iter;
	
	

	@Before
	public void setUp(){
		myTree.insert(new String("caramel"));
		myTree.insert(new String("beach"));
		myTree.insert(new String("san-diego"));
		myTree.insert(new String("butter"));
		
		
		myTree.insertInformation("caramel", "starbucks");
		assertEquals("caramel now has starbucks", "starbucks", myTree.findMoreInformation("caramel").getFirst());
		myTree.insertInformation("beach", new String("california"));
		assertTrue("beach now has california", myTree.findMoreInformation("beach").contains("california"));
		myTree.insertInformation("beach", "florida");
		assertTrue("beach now has florida", myTree.findMoreInformation("beach").contains("florida"));
		myTree.insertInformation("beach", "party");
		
		myTree.insertInformation("san-diego", "california");
		myTree.insertInformation("san-diego", "UCSD");
		myTree.insertInformation("san-diego", "CSE");
		
		myTree.insertInformation("butter", "bread");
		myTree.insertInformation("butter","dairy");
		myTree.insertInformation("butter", "popcorn");
		
		iter=myTree.iterator();
		
	}
	
	
	@Test
	public void testFindHeight(){
		assertEquals("height is 2",2,myTree.findHeight());
	}
	
	
	@Test
	public void testFindKey(){
		assertTrue("tree has butter",myTree.findKey("butter"));
		assertTrue("tree has san-diego",myTree.findKey("san-diego"));
		assertTrue("tree has beach",myTree.findKey("beach"));
		assertTrue("tree has caramel", myTree.findKey("caramel"));
		
		assertTrue("tree has caramel", myTree.findKey("caramel"));
		
	}
	
	
	@Test
	public void testFindMoreInfo(){
		
		LinkedList<String> storeLL = null;
		/*
		try {
			myTree.findMoreInformation("scotch");
			fail("should have generated exception");
		} catch(IllegalArgumentException e){
			
		}
		*/
		try{
			myTree.findMoreInformation(null);
			fail("should have generated exception");
		}catch (NullPointerException e){
			
		}
		
		assertTrue("tree has caramel", myTree.findKey("caramel"));
		
		storeLL = myTree.findMoreInformation("caramel");
	
		assertTrue("storeLL contains caramel's starbucks",storeLL.contains("starbucks"));
		assertEquals("1st info in san-diego is california","starbucks",storeLL.getLast());	
		
	}
	
	@Test
	public void testGetRoot(){
		
		
		assertEquals("root is caramel","caramel", myTree.getRoot().getKey());
	}
	
	@Test
	public void testGetSize(){
		
		assertEquals("siz is 4", 4, myTree.getSize());
	}
	
	
	@Test
	public void testInsert(){
		
		myTree.insert("chocolate");
		
		assertTrue("chocolate is in tree",myTree.findKey("chocolate"));
	}
	
	@Test
	public void testInsertInfo(){
		myTree.insertInformation("caramel", "starqucks");
		assertTrue("caramel now has starbucks", myTree.findMoreInformation("caramel").contains("starqucks"));
		myTree.insertInformation("beach", new String("cali"));
		assertTrue("beach now has cali", myTree.findMoreInformation("beach").contains("cali"));
		myTree.insertInformation("beach", "flora");
		assertTrue("beach now has flora", myTree.findMoreInformation("beach").contains("flora"));
		
	}
	
	
	@Test
	public void testLeafCount(){
		assertEquals("leaves in tree are 2",2, myTree.leafCount());
	}
	
	@Test
	public void testHastNext(){
		assertTrue("iter should have next",iter.hasNext());
	}
	
	@Test
	public void testNext(){
		assertEquals("1st next is beach", "beach",iter.next());
		assertEquals("2nd next is butter","butter",iter.next());
		assertEquals("3rd next is caramel","caramel",iter.next());
		assertEquals("4th next is san-diego","san-diego",iter.next());
	}
}
