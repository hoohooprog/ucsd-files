#include <stdio.h>

/*
 * Name: Jingyi Tay
 * PID: A99014740
 * LOGIN: CS12WAMF
*/

int main(){

    int numOfElem;

    int largestElem =0;
  
    int largestElemIndex;

    printf("Enter the number of elements that will be in the ");
    printf("array\n");

    scanf("%d", &numOfElem);


    printf("Enter %d integers\n", numOfElem);

    if (numOfElem == 0){
        printf("No max value because the array has nothing in it!\n");
        return;
    }

    int arrayInt[numOfElem];
    int iter;

    for (iter=0; iter<numOfElem; iter++){

        scanf("%d", &arrayInt[iter]);

        if ( arrayInt[iter] >= largestElem ){

            largestElem = arrayInt[iter];
            largestElemIndex = iter+1;    
        }
    }


    printf("Max element location = %d", largestElemIndex);
    printf(" and value = %d\n", largestElem);


    return 0;

}
