#include "stack.h"
#include <string.h>

/*
 * Initializes a stack
 * Return:
 *   Normal: An empty stack
 *   When there is no memory available to allocate: null pointer
 */
Stack * stack_init(){
	
	Stack* ptr2Stack = (Stack*)malloc(sizeof(Stack));
	
	// memory to store 100 char*
	ptr2Stack->array = (char **)malloc(sizeof(char*)*STACK_SIZE);
	
	ptr2Stack->top = STACK_EMPTY;
	
	return ptr2Stack;
	
}


/*
 * Pushes to a stack
 * Param:
 *   item - the stuff to be pushed
 */
void push(Stack* stack, char* str){
	
	int top = stack->top;
	
	stack->array[(stack->top)+1] = (char *)malloc(sizeof(char)*sizeof(str));

    strcpy(stack->array[(stack->top)+1], str);
	
    stack->top += 1;	
}


/*
 * Pops from a stack
 */
char* pop(Stack* stack){

    char* ptr2top = NULL;
	if (stack->top == -1){
		
	}
	else{
	    // access ptr to char ptr to get the array of char ptr and 
	    // get the element in that array and assign to ptr2top
	    ptr2top = (stack->array)[(stack->top)];
	
	    // make ptr in array point to 0/null
	    (stack->array)[(stack->top)] = NULL;
	
	    // decrement top by 1
	    stack->top -= 1;
	}
	return ptr2top;
}


/*
 * Returns top element of stack
 */
char * peek(Stack* stack){
	
	char* ptr2top = NULL;
	
	if (stack->top == -1){
		
		return NULL;
	}
	else{
	    ptr2top = (stack->array)[(stack->top)];
	}
	return ptr2top;
}


/*
 * Destructs a stack
 */
void stack_delete(Stack* stack){
	
	int i = 0;
	
	for (i=0; i<STACK_SIZE;i++){
		
		int j=0;
	
        char* ptrOfStr = stack->array[i];

        for (j=0; j<sizeof(ptrOfStr); j++){
			free(ptrOfStr);
		}		
		
	}
	free(stack);
}


/*
 * Prints out the information of a stack
 */
void print(Stack* stack){
	
	int top = stack->top;
	
	if (top == -1){
		printf(STR_PRINT_NO_ITEMS);
		return;
	}
	else{
	    printf(STR_PRINT_ITEMS);
	
	    //counter
	    int i=0;
	
	    for (i; i< (stack->top)+1; i++){
		    printf(" ");
		    printf(stack->array[i]);
	    }
	}
}


/*
 * Checks if the stack is empty
 */
int isEmpty(Stack* stack){
	
	int top;
	top = stack->top;
	
	if (top == STACK_EMPTY){
		return TRUE;
	}
	else{
		return FALSE;}
	
}