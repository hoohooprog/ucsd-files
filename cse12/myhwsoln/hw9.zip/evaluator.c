#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include <string.h>

#define LEFT_PARENTHESIS 40
#define RIGHT_PARENTHESIS 41
#define MULTIPLY 42
#define ADDITION 43
#define SUBTRACTION 45
#define DIVISION 47
#define MODULUS 37
#define TWO 2
#define ZERO 0
#define ONE 1
#define HIGH 3
#define MID 2
#define LOW 1

//type conversions
char* charToString(char c);
char stringToChar(char* str);
char* intToString(int res);
int stringToInt(char* str);

// helper for precedence
int precedence(char x);
//function that converts pre to post without checking
char* convertToPostFix(char* str);
//check for correct order and pair of parenthesis
int checkParentheses(char* s);



//Type conversions starts here//

char* charToString(char c) {
	
	char *str = (char*)malloc(sizeof(char)*TWO);
	str[ZERO] = c;
	str[ONE] = '\0';
	return str;
}
char stringToChar(char* str) {
	return str[ZERO];
}

char* intToString(int res) {
	char *str = (char*)malloc(BUFSIZ);
	sprintf(str,"%d",res);
	return str;
}

int stringToInt(char* str) {
	return atoi(str);
}
//Type conversions end here

// --------------------------------------------------------------------------

//Helper function to return precedence of operator
int precedence(char x) {
	
	switch (x) {
		case LEFT_PARENTHESIS :
		    return HIGH;
			break;
			
		case RIGHT_PARENTHESIS :
		    return HIGH;
			break;
			
		case MULTIPLY :
		    return MID;
			break;
			
		case DIVISION :
		    return MID;
			break;
			
		case MODULUS :
		    return MID;
			break;
			
		case ADDITION :
		    return LOW;
			break;
			
		case SUBTRACTION :
		    return LOW;
			break;
			
	    default:
		    return ZERO;
			break;
	}
}


char* convertToPostFix(char* str) {
	
	// creates a new stack to store operator
    // and points to it
	Stack* operatorStack = stack_init();
	
	// input char ptr that points to string to be scanned
	char* str2Store = str;
	
	// to point to arranged postfix(postFixArr)
	char* postfix;
	
	// to store postfixed for postfix ptr
	char postFixArr[strlen(str2Store)];
	
	// counter for for loop
	int i = 0;
	// counter for postfix
	int postCount = 0;
	
	// points double char ptr/ array of ptr to store str
	// stores operator or operand respectively
	for (i=0; i<strlen(str2Store); i++){
	    
		// ptr to get token from original string
		char* tempPtr = str2Store+i;
		
		int precedLevel = precedence(*tempPtr);
	
		// if char contained is 0-9
		if ( precedLevel == 0){
	    
		    postFixArr[postCount] = *tempPtr;
			
			// increase postCount to point at next index
			postCount++;
			
		}
		// char in index is operator, push to stack unless
		// precedence of operator at top of stack is equiv
		// or higher, then push
		else{
		   
		    char *topOfStack;
			int topPredLvl;
			
			if (isEmpty(operatorStack)){
			    topOfStack = NULL;
				topPredLvl = 0;
			}
			else{
				topOfStack = peek(operatorStack);
				topPredLvl = precedence(*topOfStack);
			}
			
			// if current token is special case do this
			if ((int)*tempPtr == RIGHT_PARENTHESIS){
	
	            char* findLeftParent = pop(operatorStack);
				
			    // store top of stack to array until empty
				// or left is found 
				while ( *findLeftParent != LEFT_PARENTHESIS &&
				      !isEmpty(operatorStack) ){
									             
				    postFixArr[postCount] = *findLeftParent;
					
				    postCount++;
					             
					// assign new token until left is found
				    findLeftParent = pop(operatorStack);
				
				}
	
			}
			//if is left parenthesis, highest precedent
			else if ((int)*tempPtr == LEFT_PARENTHESIS){
				char* tempOp = charToString(*tempPtr);
			    // push to operator stack
			    push(operatorStack, tempOp);
			}
			// 2nd level precedence
			else{ 
			    if (precedLevel == 2 ){
					
					char* divPtr;
					char* modPtr;
					
					// token is division
					if (*tempPtr == DIVISION){
						divPtr = "/";
						
					}
					
					//token is mod
					if (*tempPtr == MODULUS){
						modPtr = "%";
					}
				
			        // if top is of higher precedence, pop and store
				    // in postfixArr, unless it is left parenthesis
				    while (topPredLvl >= 2 && !isEmpty(operatorStack)
						&& *topOfStack != LEFT_PARENTHESIS){
						 
						 
						 // if token is right, pop everything until left
						 // is met
						 if ((int)*tempPtr == RIGHT_PARENTHESIS){
	
                             char* findLeftParent = pop(operatorStack);
				
			                 // store top of stack to array until empty
				             // or left is found 
				             while ( *findLeftParent != LEFT_PARENTHESIS &&
				                  !isEmpty(operatorStack) ){
					
					             
				                 postFixArr[postCount] = *findLeftParent;
					
				                 postCount++;
					             
								 // assign new token until left is found
				                 findLeftParent = pop(operatorStack);
				
				             }
				
			             }
						 
						 // if top is any higher precedence other than
						 // left, pop and store in postfixarray
                         if (*topOfStack != LEFT_PARENTHESIS){
							 
				             char *opOnStack = pop(operatorStack);
						  
					         postFixArr[postCount] = *opOnStack;
						  
					         postCount++;
						 
						     if (!isEmpty(operatorStack)){
							 
							     topOfStack = peek(operatorStack);
							 
							     topPredLvl = precedence(*topOfStack);
						     }
						  
					     }
						 
			        }
					
					// insert token(division) into stack
					if (*tempPtr == DIVISION){
						push(operatorStack, divPtr);
					}
					// insert token(mod) into stack
					else if (*tempPtr == MODULUS){
						push(operatorStack, modPtr);
					}
					// insert other lvl 2(*) into stack
				    else{
				        char* tempOp = charToString(*tempPtr);
					
				        push(operatorStack, tempOp);
					}
					  
			     }
			     // 3rd level precedence
			     else{
			        
				     while ( topPredLvl >= 1 && !isEmpty(operatorStack) 
						 && *topOfStack != LEFT_PARENTHESIS){
							 
						 // if token is right, pop everything until left
						 // is met
						 if ((int)*tempPtr == RIGHT_PARENTHESIS){
	
                             char* findLeftParent = pop(operatorStack);
				
			                 // store top of stack to array until empty
				             // or left is found 
				             while ( *findLeftParent != LEFT_PARENTHESIS &&
				                  !isEmpty(operatorStack) ){
					
					             
				                 postFixArr[postCount] = *findLeftParent;
					
				                 postCount++;
					             
								 // assign new token until left is found
				                 findLeftParent = pop(operatorStack);
				
				             }
				
			             }
					 		 
                         // if top is any higher precedence other than
						 // left, pop and store in postfixarray
                         if (*topOfStack != LEFT_PARENTHESIS){
							 
				             char *opOnStack = pop(operatorStack);
						  
					         postFixArr[postCount] = *opOnStack;
						  
					         postCount++;
						 
						     if (!isEmpty(operatorStack)){
							 
							     topOfStack = peek(operatorStack);
							 
							     topPredLvl = precedence(*topOfStack);
						     }
						  
					     }
							  
				     } 
					 
					// push lvl 1 char after all popping of higher
                    // precedence is done					
		            char *tempOp = charToString(*tempPtr);
				
				    push(operatorStack, tempOp);
				
			     }
		    
			}
        }
        		
	}
	
	// clear remaining operators of the stack,if any
    while (!isEmpty(operatorStack)){
		
		print(operatorStack);
		
		//get the operator from the top of stack as current token
		char *opOnStack = pop(operatorStack);
		
		char *topOfStack;
		
		if (!isEmpty(operatorStack)){
		    topOfStack = peek(operatorStack);
		}
		else{
			postFixArr[postCount] = stringToChar(opOnStack);
			
			postCount++;
			
			postFixArr[postCount] = '\0';			
			
			postCount++;
			
			postfix = postFixArr;
			return postfix;
		}
		// find value of current token and top 
		int popPredLvl = precedence(*opOnStack);
        int topPredLvl = precedence(*topOfStack);

        // if token is right, pop everything until left
		// is met
		if ((int)*opOnStack == RIGHT_PARENTHESIS){
	
            char* findLeftParent = pop(operatorStack);
				
			// store top of stack to array until empty
		    // or left is found 
		    while ( *findLeftParent != LEFT_PARENTHESIS &&
				  !isEmpty(operatorStack) ){
		
		        postFixArr[postCount] = *findLeftParent;
					
				postCount++;
					             
				// assign new token until left is found
				findLeftParent = pop(operatorStack);
				
		    }
				
		}		

 		if (popPredLvl <= topPredLvl){
		    
			// if top is any higher precedence other than
			// left, pop and store in postfixarray
            if (*topOfStack != LEFT_PARENTHESIS){
							 
			    char *opOnStack1 = pop(operatorStack);
						  
			    postFixArr[postCount] = *opOnStack1;
						  
			    postCount++;
						  
		    }	
			
		}
		else{
			postFixArr[postCount] = *opOnStack;
			
			postCount++;
		}
		
    }
	
	// after add and remove ops from stack, check if
	// string has \0, if not add.
	if (postFixArr[postCount] != '\0'){
		
		postCount++;
		
		postFixArr[postCount] = '\0';
		
	}
	
	// check if char ptr to arr is right way(probably right)
	postfix = postFixArr;
	
	stack_delete(operatorStack);
	
	return postfix;
	
}


int checkParentheses(char* s){
	
	Stack* checkParentheses = stack_init();
	
	char* str2Check = s;
	
	int i = 0;
	
	// iterate thru the string and only store parenthesis
	// check by comparing asc value
	for ( i=0; i<strlen(str2Check); i++){
	
        if (*(str2Check+i) == RIGHT_PARENTHESIS ||
	       *(str2Check+i) == LEFT_PARENTHESIS){
		
		    char* char2Push = charToString(*(str2Check+i));
		    push(checkParentheses, char2Push);
			
	    }		
	}
		
	// pop top and make sure right has left
	// if top is left, not balance
	// if right right, not balance
	// if right left left, not balance
	if (isEmpty(checkParentheses)){
		return 1;
	}
	else{
		
		
		if (*peek(checkParentheses) == LEFT_PARENTHESIS){
			return 0;
		}
		else{
			
			while (!isEmpty(checkParentheses)){
							
			    char* poppedRight = pop(checkParentheses);
				
				if ( *poppedRight != RIGHT_PARENTHESIS ||
				    isEmpty(checkParentheses) ){
					
					return 0;
				}
			
			    if ( *peek(checkParentheses) != LEFT_PARENTHESIS ) {
				    return 0;
			    }
				else{
					char* poppedLeft = pop(checkParentheses);
				}
		    }
	    }
		
		return 1;
    }

	stack_delete(checkParentheses);
}


int calculateExpression(char* str) {
	//TODO
	return -1;
}


int main(int argc, char **argv) {
	
	if(argc<TWO) {
		printf(STR_INCORRECT_ARGUMENT);
	} else {
		
		//TODO CHANGE BELOW!!
		char* input = argv[1];  
		
		if (!checkParentheses(input)){
		    printf(STR_NOT_BALANCED);
            return EXIT_SUCCESS;			
		}
		
		char* postfix = convertToPostFix(input);
		int answer;
		//TODO CHANGE ABOVE!!
		
		printf(STR_POSTFIX_EXPRESSION,postfix);
		printf(STR_RESULT,answer);
		free(input);
		free(postfix);
	}
	return EXIT_SUCCESS;
}

