package hw1;
import java.util.*;

class Pig {


    //Counter to maintain the human's score
    private int counterH = 0;

    //Counter to maintain the computer's score
    private int counterC = 0;

    //This variable specifies the minimum score required to win the game
    private int GAME_OVER = 20;

    //Object of Random class to get a random value
    Random rand = new Random();

    //Object of Stats class to maintain statistics
    static Stats stats = new Stats();


    /**
     * This function models the Human's turn. Two dies are rolled in each turn.
     * If both the rolls result in 1, the entire score is reset to 0 and the control is passed to the computer
     * If either of the rolls is 1, the control is passed to the computer
     * If the rolls aren't equal to 1, but are identical, the score is added and the Human is forced to continue
     * If the rolls aren't equal to 1, but aren't identical, the score is added and the Human is asked for his choice between coninue and hold
     */
    void  HumanMove(){

        /* TODO: Complete the method */
    }


    /**
     * This function models the Computer's turn. Two dies are rolled in each turn.
     * If both the rolls result in 1, the entire score is reset to 0 and the control is passed to the computer
     * If either of the rolls is 1, the control is passed to the computer
     * If the rolls aren't equal to 1, but are identical, the score is added and the Human is forced to continue
     * If the rolls aren't equal to 1, but aren't identical, the score is added and the Human is asked for his choice between coninue and hold
     */
    void  ComputerMove(){

       /* TODO: complete the method */
    }


    /**
     * This method displays the overall scores
     */
    private void getScores()
    {
        System.out.println("-----------------------------------");
        System.out.println("Scores.  You: " + counterH + ", Computer: " + counterC );
        System.out.println("-----------------------------------");
    }

    /**
     * This method models the game by passing control between the human and the computer.
     * Whoever succeeds in scoring at least GAME_OVER number of points first, wins the game.
     * Ensure that Human always starts first
     * @return 1: if the human wins, 2: if the computer wins
     */
    int game() {

        /* TODO: finish the method */
    }

    /**
     * This method is used to reset the Human's score before a new game.
     */
    void resetCounterH()
    {
        counterH = 0;
    }

    /**
     * This method is used to reset the Computer's score before a new game.
     */
    void resetCounterC()
    {
        counterC = 0;
    }

    public static void main(String [] args) {

        Pig pig = new Pig();

        do {
            /* TODO: complete the method */
        } while(???);

        System.out.println("Thank You for playing!");
    }

}
